﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using studentbo;
using stdenentdal;
using System.Data;
using Types;

namespace stbll
{
    public class stdbll:IStudentBLL
    {

        public int AddStudent(IStudentBO objbo)
        {
            IStudentDAL objclass = new stddal();
            return objclass.AddStudent(objbo);
        }

        public void DeleteStudent(string studeid)
        {
            IStudentDAL objclass = new stddal();
            objclass.DeleteStudent(studeid);


        }

        public int  updateStudent(IStudentBO objbo)
        {
            IStudentDAL objclass = new stddal();
            return objclass.updateStudent(objbo);


        }
        
        public DataTable ViewStudent()
        {
            DataTable dt;
            IStudentDAL objclass = new stddal();

            dt= objclass.ViewStudent();

            dt.Columns.Add("Status");

            foreach (DataRow dr in dt.Rows)
            {
                if (dr["Active"].ToString() == "1")
                {
                    dr["Status"] = "Active";

                }
                else
                {
                    dr["Status"] = "InActive";
                }

            }

            dt.Columns.Remove("Active");



            return dt;
        }

        public List<IStudentBO> ViewStudentList()
        {
            
            IStudentDAL objclass = new stddal();
            return objclass.ViewStudentList();

        }

        public string LoginStudent(ILoginBO objbo)
        {
            IStudentDAL objclass = new stddal();
            return objclass.LoginStudent(objbo);
        }



    }
}
