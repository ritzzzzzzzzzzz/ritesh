﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Types;

namespace Types
{
    public interface IStudentDAL
    {
        int AddStudent(IStudentBO objbo);
        void DeleteStudent(string studeid);
        int updateStudent(IStudentBO objbo);
        DataTable ViewStudent();
        List<IStudentBO> ViewStudentList();
         string LoginStudent(ILoginBO objbo);

    }
}
