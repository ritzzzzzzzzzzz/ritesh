﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using studentbo;
using stbll;
using System.Data;

namespace WebApplication4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["role"] == null)
            {
                Response.Redirect("WebForm2.aspx");
            }
            else
            {
                Response.Write(Session["role"]);
            }

            

            if (!Page.IsPostBack)
            {
                LoadControls();
                LoadGrid();
            }

        }

        private void LoadControls()
        {
            lblmsg.Visible = false;
        }

        private void LoadGrid()
        {
            student objbllstud = new student();
            DataTable dt=objbllstud.ViewStudent();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "No student details to deisplay";
                }
                else
                {
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Error in dispalying student details";
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            studbo objstud = new studbo();
            objstud.ID = int.Parse(TextBox1.Text);
            objstud.Name = TextBox2.Text;

            student objbllstud = new student();
            int intresult=objbllstud.AddStudent(objstud);

            lblmsg.Visible = true;


            if (intresult == 1)
            {
                lblmsg.Text="Details added sucessfully";
            }
            else if (intresult == -2)
            {
                lblmsg.Text = "Same ID exists";
            }



        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            GridViewRow grdrow = e.Row;
            TableCell gcell = grdrow.Cells[0];
            grdrow.Cells.Remove(gcell);
            grdrow.Cells.AddAt(2, gcell);

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
        }

        protected void emp_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            LoadGrid();



        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            int intEditrowindx = e.RowIndex;
            GridViewRow grdrow = GridView1.Rows[intEditrowindx];
            int intstudentid=int.Parse(GridView1.DataKeys[intEditrowindx].Value.ToString());
           
            
            TextBox txtstatus = (TextBox)grdrow.FindControl("TextBox3");
            string strstatus = txtstatus.Text;

            studbo objbo=new studbo();
            objbo.Status=strstatus;
            objbo.ID=intstudentid;

            student objbll = new student();

           // objbll.updateStudent(objbo);
            GridView1.EditIndex = -1;
            LoadGrid();
             

        





        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            LoadGrid();
        }

        protected void GridView1_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Cancel")
            {
                int id = int.Parse(e.CommandArgument.ToString());

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
         //   Response.Redirect("WebForm3.aspx");
            foreach(GridViewRow grdrow in GridView1.Rows)

            {
              //  Checkbox chk = (CheckBox)grdrow.FindControl("CheckBox1");

            }


        }
    }
}