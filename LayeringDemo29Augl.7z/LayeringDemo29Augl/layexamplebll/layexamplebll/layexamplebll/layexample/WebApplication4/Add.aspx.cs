﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using studentbo;
using stbll;
using System.Data;
using Types;

namespace WebApplication4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!Page.IsPostBack)
            {
                LoadControls();
                LoadGrid();
            }

        }

        private void LoadControls()
        {
            lblmsg.Visible = false;
        }

        private void LoadGrid()
        {
            IStudentBLL objbllstud = new stdbll();
            DataTable dt = objbllstud.ViewStudent();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "No student details to deisplay";
                }
                else
                {
                    grdViewDT.DataSource = dt;
                    grdViewDT.DataBind();
                }
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Error in dispalying student details";
            }

            List<IStudentBO> lstbo = objbllstud.ViewStudentList();
            grdViewList.DataSource = lstbo;
            grdViewList.DataBind();


        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            IStudentBO objstud = new studbo();
            objstud.ID = txtUserID.Text;
            objstud.Password = txtPassword.Text;

            IStudentBLL objbllstud = new stdbll();
            int intresult = objbllstud.AddStudent(objstud);

            lblmsg.Visible = true;


            if (intresult == 1)
            {
                lblmsg.Text = "Details added sucessfully";
                LoadGrid();
            }
            else if (intresult == -2)
            {
                lblmsg.Text = "Same ID exists";
            }



        }

    }
}