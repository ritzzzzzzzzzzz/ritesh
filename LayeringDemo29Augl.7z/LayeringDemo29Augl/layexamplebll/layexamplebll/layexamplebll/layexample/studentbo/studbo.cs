﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Types;

namespace studentbo
{
    public class studbo:IStudentBO
    {
        string id;
        string password;
        string status;

        public string ID
        {
            get
            {
                return id;
            }

            set
            {
                id = value;
            }
        }

        public string Password
        {
            get 
            {
                return password;
            }

            set
            {
                password = value;
            }
        }



        public string Status
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }


    }
}
