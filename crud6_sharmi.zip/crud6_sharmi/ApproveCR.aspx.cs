﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace omr_gropu6
{
    public partial class ApproveCR : System.Web.UI.Page
    {
        string status;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Btn_ViewCR(object sender, EventArgs e)
        {

            bindgrid();
        }
        private void bindgrid()
        {
            IBuisness objapp = new clsbuisness();
            DataTable dt = objapp.Viewallsr();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    Label4.Visible = true;
                    Label4.Text = "No Change requests  to display";
                }
                else
                {

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                Label4.Visible = true;
                Label4.Text = "Error in dispalying chnge requests ";
            }
        }
    }
            protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            IBO objbo = new empbobject.clsbo();
            IBuisness objapp = new clsbuisness();
            if (e.CommandName == "new")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];
                string requestNo = row.Cells[0].Text;
                objbo.idd = requestNo;
                objbo.Status = "Approved";
            }

            else 
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];
                string requestNo = row.Cells[0].Text;
                objbo.idd = requestNo;
                objbo.Status = "Rejected";
            }
            int result = objapp.CRstatus(objbo);
        }

    }
    
