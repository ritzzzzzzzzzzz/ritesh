﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using empdal;
using System.Data;
using Types;

namespace empbusiness
{
    class Appcrbll
    {
        public int srappstatus(IBO objbo)
        {
            IDAL objdatalayer = new clsdal();
            return objdatalayer.srappstatus(objbo);
        }
        public DataTable Viewallcr()
        {
            DataTable dt;
            IDAL datalayer = new clsdal();
            dt = datalayer.Viewallcr();

            return dt;
        }
    }
}
