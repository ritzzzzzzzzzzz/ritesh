﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using Types;

namespace empdal
{
    class Appcrdal
    {
        public DataTable Viewallcr()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
                //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                //ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = " sp_viewcr";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
        public DataTable CRstatus(IBO objcr)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
                //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                //ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = " sp_viewcr";
                cmd.Parameters.AddWithValue("@cr_id", objcr.idd);
                cmd.Parameters.AddWithValue("@status", objcr.Status);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public int srappstatus(IBO objcust)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;
            string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
            //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
            conn.ConnectionString = str;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "approveapp";
            cmd.Parameters.AddWithValue("@application_no", objcust.idd);
            cmd.Parameters.AddWithValue("@status", objcust.Status);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            ret = cmd.ExecuteNonQuery();
            conn.Close();
            return ret;

        }

    }
}

