﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using empdal;
using empbobject;
using System.Data;
using Types;
namespace empbusiness
{
    public class viewcrbll:IVIEWCRBLL
    {
        
        public DataTable viewall()
        {
            IVIEWCRDAL objdal = new viewcrdal();
            return objdal.viewall();
        }
        public int forward(IVIEWCRBO bo)
        {
            IVIEWCRDAL objdal = new viewcrdal();
            return objdal.forward(bo);
        }
       public  DataTable ViewbyCR(IVIEWCRBO bo)
        {
            DataTable dt;
            IVIEWCRDAL objdal = new viewcrdal();
            dt= objdal.ViewbyCR(bo);
            return dt;
        }
    }
}
