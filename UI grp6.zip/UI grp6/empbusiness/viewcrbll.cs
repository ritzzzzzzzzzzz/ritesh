﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using empdal;
using empbobject;
using System.Data;
namespace empbusiness
{
    public class viewcrbll
    {
        viewcrdal objdal = new viewcrdal();
        public DataTable viewall()
        {
            return objdal.viewall();
        }
    }
}
