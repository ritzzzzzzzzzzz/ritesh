﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using empbobject;
using System.Data;
using System.Data.SqlClient;

namespace empdal
{
    public class viewcrdal
    {
        public DataTable viewall()
        {
            string constr = "Data source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User id=mms73group6;Password=mms73group6";
            SqlConnection con = new SqlConnection(constr);
            //SqlCommand cmd = new SqlCommand("sp_viewcroncondition", con);
            //cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter("sp_viewcr", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "tbl_omr_g6_changevalue");
            return ds.Tables[0];

        }
    }
}
