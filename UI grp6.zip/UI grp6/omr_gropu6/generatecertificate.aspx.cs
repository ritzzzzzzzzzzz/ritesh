﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp;
using empbobject;
using empbusiness;
using Types;
using System.Data;
namespace omr_gropu6
{
    public partial class generatecertificate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        private void bindgrid()
        {
            IBuisness objapp = new clsbuisness();
            DataTable dt = objapp.Viewallstatus();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "No applications  to display";
                }
                else
                {

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Error in dispalying applications ";
            }

        }

        protected void Btnall_Click(object sender, EventArgs e)
        {


            bindgrid();
        }
    }
}