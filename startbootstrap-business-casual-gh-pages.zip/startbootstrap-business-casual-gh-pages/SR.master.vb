﻿
Partial Class SR
    Inherits System.Web.UI.MasterPage
End Class

