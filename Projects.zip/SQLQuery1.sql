create table coursee(courseid int primary key IDENTITY(1,1),coursename varchar(20),Descriptionn varchar(100),mode varchar(20),categoty varchar(20),userid varchar(20))
insert into coursee values('eee','good1','inactive','nontech','xyz')
select*from coursee
create proc sp_add_je
(@courseid int out,@coursename varchar(20),@Descriptionn varchar(100),@mode varchar(10),@category varchar(20),@userid varchar(10))
as begin
insert into coursee
values(@coursename,@Descriptionn,@mode,@category,@userid)
set @courseid=@@IDENTITY
end
