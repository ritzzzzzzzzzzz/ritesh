﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;


namespace WebApplication1
{
    public partial class Add : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
          
            TextBox4.Text = Session["category"].ToString();
            TextBox4.ReadOnly = true;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            bookbo objectbo = new bookbo();

            objectbo.Coursename = TextBox1.Text;
            objectbo.Mode = DropDownList1.SelectedItem.Text;
            objectbo.Descriptionn = TextBox3.Text;
            objectbo.Category = TextBox4.Text;
            objectbo.Userid = TextBox5.Text;

            bookBLL objbll = new bookBLL();
            int count = objbll.addcourse(objectbo);

           
            if (count > 0)
            {
                Response.Write("<script type=\"text/javascript\">alert('Succesfully added');</script>");
                TextBox1.Text = "";
                TextBox5.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";

            }
            else
            {
                Response.Write("<script type=\"text/javascript\">alert('CouldNot Add');</script>");
            }
        }
    }
}