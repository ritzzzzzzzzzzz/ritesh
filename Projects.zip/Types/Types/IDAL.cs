﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;


namespace Types
{
    public interface IDAL
    {

       // int addcourse(bookbo objbo);
        DataSet viewcourse(int courseid);
        int deletecourse(int Bookid);
    }
}
