﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    public interface IBO
    {
        int courseid { get; set; }
        string userid { get; set; }
        string coursename { get; set; }
        string descriptionn { get; set; }
        string mode { get; set; }
        string category { get; set; }

    }
}
