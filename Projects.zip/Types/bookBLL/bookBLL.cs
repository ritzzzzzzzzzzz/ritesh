﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using BO;
using DAL;

namespace BLL
{
    public class bookBLL
    {
          public int addcourse(bookbo objbo)
            {
               bookDAL objdal = new bookDAL();
         
                return objdal.addcourse(objbo);
            }
            public DataSet viewcourse(int courseid)
            {
                bookDAL objdal = new bookDAL();
                return objdal.viewcourse(courseid);
            }
            public int deletecourse(int id)
            {
               bookDAL objdal = new bookDAL();
                return objdal.deletecourse(id);
            }
          
        }
    }


