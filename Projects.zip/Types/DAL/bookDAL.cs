﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
using System.Data;
using System.Data.SqlClient;
using BO;
namespace DAL
{
    public class bookDAL
    {
        public int addcourse(bookbo objbo)
        {
            string connstring = "Data Source=inchnilpdb02\\mssqlserver1;" + "Initial Catalog=CHN09_MMS55_TEST;" + "User id=mms55test;" + "Password=mms55test;";
            SqlConnection conn = new SqlConnection(connstring);
            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "sp_add_je";
            cmd.Connection = conn;
            cmd.Parameters.AddWithValue("@courseid", 0);
            cmd.Parameters.AddWithValue("@Coursename", objbo.Coursename);
            cmd.Parameters.AddWithValue("@Description", objbo.Descriptionn);
            cmd.Parameters.AddWithValue("@mode", objbo.Mode);
            cmd.Parameters.AddWithValue("@category", objbo.Category);
            cmd.Parameters.AddWithValue("@userid", objbo.Userid);

            int count = cmd.ExecuteNonQuery();
            conn.Close();
            return count;
        }
        public DataSet viewcourse(int courseid)
        {
            string str = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;User Id=mms73user;Password=mms73user";
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "coursee";
            cmd.Connection = con;
            cmd.Parameters.AddWithValue("@courseid",courseid);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            con.Close();
            return ds;
        }
        public int deletecourse(int id)
        {
            string connstring = "Data Source=inchnilpdb02\\mssqlserver1;" + "Initial Catalog=CHN12_MMS73_TEST;" + "User id=mms73user;" + "Password=mms73user;";
            SqlConnection conn = new SqlConnection(connstring);
            SqlCommand cmd = new SqlCommand();
            conn.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "coursee";
            cmd.Connection = conn;
            cmd.Parameters.AddWithValue("courseid",id);
            int rowsaffected = cmd.ExecuteNonQuery();
            conn.Close();
            return rowsaffected;

        }
    }
}
