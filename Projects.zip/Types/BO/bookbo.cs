﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace BO
{
    public class bookbo
    {
       int courseid;
      string userid;
        string coursename;
        string descriptionn;
       string mode;
       string category;
        public int Courseid
        {
            get { return courseid; }
            set { courseid = value; }
        }
        public string Userid
        {
            get { return userid; }
            set { userid = value; }
        }
        public string Coursename
        {
            get { return coursename; }
            set { coursename = value; }
        }
        public string Descriptionn
        {
            get { return descriptionn; }
            set { descriptionn = value; }
        }
        public string Mode
        {
            get { return mode; }
            set { mode = value; }
        }
        public string Category
        {
            get { return category; }
            set { category = value; }
        }
        public bookbo()
        {

        }

    }
}
