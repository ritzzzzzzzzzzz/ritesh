﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    public class IBO
    {
     public   string idd{ get; set; }
        public string location { get; set; }
        public string huband { get; set; }
        public string wife { get; set; }
        public string remark { get; set; }
        public string Status { get; set; }
        public int id { get; set; }
        public string Status1 { get; set; }
        public int IDD { get; set; }
        public string col_name { get; set; }
        public string old_val { get; set; }
        public string new_val { get; set; }
        public string statuss { get; set; }
        public string remarkss { get; set; }
    }
}
