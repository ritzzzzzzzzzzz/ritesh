﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
   public interface IDAL
    {
        //void insertupdatedeletesqlstring(string sqlstring);

        //DataTable detailsviewapplication(string s);
        string emplogin(ILOGINbo obj);
        DataTable Viewallstatus();
        DataTable Viewall();
        DataTable Viewallsr();
        DataTable Viewfilter(IBO objbo);
        DataTable detailsviewapplication(string s);
        int verifyapplication(IBO objvp);
        int srappstatus(IBO obj);
        DataTable Viewallcr();
        int CRstatus(IBO objcr);
        DataTable viewchangereq();
        DataTable viewchangevalue(IBO objcv);
        int changecertificate(IBO objcr);
    }
}
