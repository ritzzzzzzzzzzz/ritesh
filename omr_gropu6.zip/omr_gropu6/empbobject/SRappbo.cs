﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
namespace empbobject
{
  public  class SRappbo:IBO
    {
        int ApplicationNo;
        string statuss;
        public string Status
        {
            get { return statuss; }
            set { statuss = value; }
        }
        string remarkk;
        public string remark
        {
            get { return remarkk; }
            set { remarkk = value; }

        }

        public int ApplicationNo1
        {
            get
            {
                return ApplicationNo;
            }

            set
            {
                ApplicationNo = value;
            }
        }
    }
}
