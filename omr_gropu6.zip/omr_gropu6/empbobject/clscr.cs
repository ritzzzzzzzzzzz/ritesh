﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;

namespace empbobject
{
    public class clscr : IBO
    {
        public int app;
        private string status1;
        public int ID
        {
            get { return app; }
            set { app = value; }
        }

        public string Status1
        {
            get
            {
                return status1;
            }

            set
            {
                status1 = value;
            }
        }
    }
}
