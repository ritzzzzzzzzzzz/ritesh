﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Types;
using empbobject;
namespace empdal
{
    public class clsdal:IDAL
    {
        string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
        //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
        
        public void insertupdatedeletesqlstring(string sqlstring)
        {
            SqlConnection con = new SqlConnection(str);
            con.Open();
            SqlCommand cmd = new SqlCommand(sqlstring, con);
            cmd.ExecuteNonQuery();
        }
        public object Executesqlstring(string sqlstring)
        {
            SqlConnection con = new SqlConnection(str);
            con.Open();
            DataSet ds = new DataSet();
            SqlCommand cmd = new SqlCommand(sqlstring, con);
            SqlDataAdapter adp = new SqlDataAdapter(cmd);
            adp.Fill(ds);
            return ds;
        }
        //public IBO viewallstatus()
        //{
        //    IBO objbo = null;
        //    SqlConnection con = new SqlConnection();
        //    try
        //    {
        //        SqlCommand cmd = new SqlCommand();
        //        SqlDataAdapter adp = new SqlDataAdapter();
        //        DataTable dt = new DataTable();
        //        string conection = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
        //        con.ConnectionString = conection;
        //        cmd.Connection = con;
        //        con.Open();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "sp_viewallstatus";

        //        adp.SelectCommand = cmd;
        //        adp.Fill(dt);
        //        con.Close();
        //        while (dt.Rows.Count > 0)
        //        {
        //            int i = Convert.ToInt32(dt.Rows[0]["application_no"].ToString());
        //            string hus = dt.Rows[0]["Husbandname"].ToString();
        //            string wife = dt.Rows[0]["wifename"].ToString();
        //            DateTime dtt = Convert.ToDateTime(dt.Rows[0]["marraigedate"].ToString());
        //            string loc = dt.Rows[0]["mgrlocation"].ToString();
        //            objbo =new empbobject.clsbo(i, hus, wife, dtt, loc);
        //        }
        //    }

        //}
        public int verifyapplication(IBO objva)
        {
            int app = 0;
            SqlConnection conn1 = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                // string str =   ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                      string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
                //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                conn1.ConnectionString = str;
                conn1.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@remarks",objva.remark);
                cmd.Parameters.AddWithValue("@application_no", objva.idd);
                cmd.CommandText = "sp_verifyapp";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn1;
                da.SelectCommand = cmd;
                app = cmd.ExecuteNonQuery();
                conn1.Close();
            }
            //catch (SqlException sqlex)
            //{


            //    if (sqlex.Message.Contains("PRIMARY KEY"))
            //    {
            //        app = -2;
            //    }
            //    else
            //    {
            //        app = -1;
            //    }

            //}
            //catch (Exception e)
            //{
            //    app = -1;
            //}
            finally
            {
                if (conn1.State == ConnectionState.Open)
                {
                    conn1.Close();
                }

            }
            return app;
        }
        public string emplogin(ILOGINbo obj)
        {
            DataTable dt = new DataTable();
            SqlConnection conn1 = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
               // string str =   ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
                      string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
               //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                conn1.ConnectionString = str;
                conn1.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@userid", obj.Username );
                cmd.Parameters.AddWithValue("@password", obj.txtpwd);
                cmd.CommandText = "Select Role from tbl_omr_g6_employee where employee_id=@userid and password=@password";
             

                cmd.Connection = conn1;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn1.Close();
                if (dt.Rows.Count == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return dt.Rows[0]["Role"].ToString();
                }


            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn1.State == ConnectionState.Open)
                {
                    conn1.Close();
                }
            }

        }
        public DataTable detailsviewapplication(string s)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                string d1 = s;
                string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
                //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@application_no",d1);
                cmd.CommandText = "viewapplication";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public DataTable Viewallstatus()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
               // string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                //ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "sp_viewallstatus";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
        public DataTable Viewall()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
                //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                //ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "sp_viewall";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
        public DataTable Viewfilter(IBO obj)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();
           
            try
            {
                System.Text.StringBuilder s = new System.Text.StringBuilder();
                s.AppendFormat("select a.application_no,d.firstname as Husbandname,c.firstname as wifename,a.marraigedate,a.mgrlocation,a.Created_date,a.status from  tbl_omr_g6_application a,tbl_omr_g6_persondetails d,tbl_omr_g6_persondetails c where a.husbandid=d.person_id and a.wifeid = c.person_id  and 1=1 ");


                if (!String.IsNullOrEmpty(obj.idd))
                {
                    s.AppendFormat(" AND application_no =" + obj.idd);

                }
                else
                { }
                if (!String.IsNullOrEmpty(obj.huband))
                {
                    s.AppendFormat(" AND d.firstname ='" + obj.huband+"'");

                }
                if (!String.IsNullOrEmpty(obj.wife))
                {
                    s.AppendFormat(" AND c.firstname  ='" + obj.wife+"'");

                }
                if (!String.IsNullOrEmpty(obj.location))
                {
                    s.AppendFormat(" AND Mgrlocation ='" + obj.location+"'");

                }

                SqlDataAdapter da = new SqlDataAdapter();
                string d = s.ToString();
                string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
                //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = d;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public DataTable Viewallsr()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
                //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                //ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "sp_viewallsr";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
        public int srappstatus(IBO objcust)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;
            string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
            //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
            conn.ConnectionString = str;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "approveapp";
            cmd.Parameters.AddWithValue("@status", objcust.Status);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            ret = cmd.ExecuteNonQuery();
            conn.Close();
            return ret;

        }

    }
}