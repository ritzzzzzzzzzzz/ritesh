﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Types;
using empbobject;
namespace empdal
{
    public class clsdal:IDAL
    {
       
        //public IBO viewallstatus()
        //{
        //    IBO objbo = null;
        //    SqlConnection con = new SqlConnection();
        //    try
        //    {
        //        SqlCommand cmd = new SqlCommand();
        //        SqlDataAdapter adp = new SqlDataAdapter();
        //        DataTable dt = new DataTable();
        //        string conection = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
        //        con.ConnectionString = conection;
        //        cmd.Connection = con;
        //        con.Open();
        //        cmd.CommandType = CommandType.StoredProcedure;
        //        cmd.CommandText = "sp_viewallstatus";

        //        adp.SelectCommand = cmd;
        //        adp.Fill(dt);
        //        con.Close();
        //        while (dt.Rows.Count > 0)
        //        {
        //            int i = Convert.ToInt32(dt.Rows[0]["application_no"].ToString());
        //            string hus = dt.Rows[0]["Husbandname"].ToString();
        //            string wife = dt.Rows[0]["wifename"].ToString();
        //            DateTime dtt = Convert.ToDateTime(dt.Rows[0]["marraigedate"].ToString());
        //            string loc = dt.Rows[0]["mgrlocation"].ToString();
        //            objbo =new empbobject.clsbo(i, hus, wife, dtt, loc);
        //        }
        //    }

        //}
        public int verifyapplication(IBO objva)
        {
            int app = 0;
            SqlConnection conn1 = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn1.ConnectionString = str;
                conn1.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@remarks",objva.remark);
                cmd.Parameters.AddWithValue("@application_no", objva.idd);
                cmd.CommandText = "sp_verifyapp";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn1;
                da.SelectCommand = cmd;
                app = cmd.ExecuteNonQuery();
                conn1.Close();
            }
            catch (SqlException sqlex)
            {


                if (sqlex.Message.Contains("PRIMARY KEY"))
                {
                    app = -2;
                }
                else
                {
                    app = -1;
                }

            }
            catch (Exception e)
            {
                app = -1;
            }
            finally
            {
                if (conn1.State == ConnectionState.Open)
                {
                    conn1.Close();
                }

            }
            return app;
        }
        public string emplogin(ILOGINbo obj)
        {
            DataTable dt = new DataTable();
            SqlConnection conn1 = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn1.ConnectionString = str;
                conn1.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@userid", obj.Username );
                cmd.Parameters.AddWithValue("@password", obj.txtpwd);
                cmd.CommandText = "Select Role from tbl_omr_g6_employee where employee_id=@userid and password=@password";
             

                cmd.Connection = conn1;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn1.Close();
                if (dt.Rows.Count == 0)
                {
                    return string.Empty;
                }
                else
                {
                    return dt.Rows[0]["Role"].ToString();
                }


            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn1.State == ConnectionState.Open)
                {
                    conn1.Close();
                }
            }

        }
        public int srappstatus(IBO objcust)
        {
            SqlConnection conn = new SqlConnection();
            int ret = 0;

            string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
            conn.ConnectionString = str;
            conn.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.CommandText = "approveapp";
            cmd.Parameters.AddWithValue("@application_no", objcust.idd);
            cmd.Parameters.AddWithValue("@status", objcust.Status);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            ret = cmd.ExecuteNonQuery();
            conn.Close();
            return ret;

        }
        public DataTable detailsviewapplication(string s)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                string d1 = s;
                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
            conn.ConnectionString = str;
            conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Parameters.AddWithValue("@application_no",d1);
                cmd.CommandText = "viewapplication";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
        }
            catch (Exception ex)
            {
                return null;
    }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public DataTable Viewallstatus()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();
                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "sp_viewallstatus";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
        public DataTable Viewall()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "sp_viewall";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
        public DataTable Viewfilter(IBO obj)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();
           
            try
            {
                System.Text.StringBuilder s = new System.Text.StringBuilder();
                s.AppendFormat("select a.application_no,d.firstname as Husbandname,c.firstname as wifename,a.marraigedate,a.mgrlocation,a.Created_date,a.status from  tbl_omr_g6_application a,tbl_omr_g6_persondetails d,tbl_omr_g6_persondetails c where a.husbandid=d.person_id and a.wifeid = c.person_id  and 1=1 ");


                if (!String.IsNullOrEmpty(obj.idd))
                {
                    s.AppendFormat(" AND application_no =" + obj.idd);

                }
                else
                { }
                if (!String.IsNullOrEmpty(obj.huband))
                {
                    s.AppendFormat(" AND d.firstname ='" + obj.huband+"'");

                }
                if (!String.IsNullOrEmpty(obj.wife))
                {
                    s.AppendFormat(" AND c.firstname  ='" + obj.wife+"'");

                }
                if (!String.IsNullOrEmpty(obj.location))
                {
                    s.AppendFormat(" AND Mgrlocation ='" + obj.location+"'");

                }

                SqlDataAdapter da = new SqlDataAdapter();
                string d = s.ToString();
                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = d;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public DataTable Viewallsr()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "sp_viewall";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
    
        public DataTable Viewallcr()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "sp_viewcr";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
        public int CRstatus(IBO objcr)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

              
                
             string str=  ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
              
                cmd.Parameters.AddWithValue("@application_no", objcr.idd);
                cmd.Parameters.AddWithValue("@status", objcr.Status);
            cmd.CommandText = "sp_crChangeStatus";
            cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                int i = cmd.ExecuteNonQuery();
                conn.Close();
                return i;
            }
            catch (Exception ex)
            {
                return 0;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public DataTable viewchangereq()
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

               
               
               string str= ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "sp_viewchangereq";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }

        public DataTable viewchangevalue(IBO objcust)
        {
            SqlConnection conn = new SqlConnection();
            try
            {

                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                DataTable dt = new DataTable();
                SqlCommand cmd = new SqlCommand();
                SqlDataAdapter da = new SqlDataAdapter();
                cmd.CommandText = "sp_viewchangevalue";
                cmd.Parameters.AddWithValue("@application_no", objcust.idd);

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public int changecertificate(IBO objcr)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();



                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();

                cmd.Parameters.AddWithValue("@application_no", objcr.idd);
                cmd.Parameters.AddWithValue("@column_name", objcr.col_name);
                // cmd.Parameters.AddWithValue("@old_value", objcr.old_val);
                cmd.Parameters.AddWithValue("@new_value", objcr.new_val);
                // cmd.Parameters.AddWithValue("@statuss", objcr.statuss);

                cmd.CommandText = "change_col";
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Connection = conn;
                da.SelectCommand = cmd;
                int i = cmd.ExecuteNonQuery();
                conn.Close();
                return i;
            }
            catch (Exception ex)
            {
                return 0;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public DataTable viewcertificate(string username)
        {
            SqlConnection conn = new SqlConnection();

            try {

                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
            conn.Open();
            DataTable dt = new DataTable();
            SqlCommand cmd = new SqlCommand();
            SqlDataAdapter da = new SqlDataAdapter();
            cmd.CommandText = "sp_viewcertificate";
            cmd.Parameters.AddWithValue("@user", username);

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Connection = conn;
            da.SelectCommand = cmd;
            da.Fill(dt);
                conn.Close();
                return dt;
            

        }
            catch (Exception ex)
            {
                return null;
    }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
        public DataTable all(String s)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                SqlDataAdapter da = new SqlDataAdapter();

                string str = ConfigurationManager.ConnectionStrings["mine"].ConnectionString;
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
            cmd.Parameters.AddWithValue("@application_no", s);
                cmd.CommandText = "sp_view_app";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
        }
            catch (Exception ex)
            {
                return null;
    }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
    }
}