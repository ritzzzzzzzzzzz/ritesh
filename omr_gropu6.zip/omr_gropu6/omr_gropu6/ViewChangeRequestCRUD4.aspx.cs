﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empbusiness;
using empbobject;
using Types;
using System.Data;
namespace omr_gropu6
{
    public partial class ViewChangeRequestCRUD4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

        }

        protected void btnviewall_Click(object sender, EventArgs e)
        {
            viewcrbll bl = new viewcrbll();
            GridView1.DataSource=bl.viewall();
            GridView1.DataBind();
        }

        //protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Verification message", "alert('Verified successfully');", true);
        //    lblrem.Visible = true;
        //    Label4.Visible = true;
        //    lblapprem.Visible = true;
        //    txtappnorem.Visible = true;
        //    lblrem.Visible = true;
        //    txtrem.Visible = true;
        //    btnfrwd.Visible = true;
        //}
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "Verification message", "alert('Verified successfully');", true);
            Response.Write("<script>alert('Verified successfully')</script>");
            lblrem.Visible = true;
            Label4.Visible = true;
            lblapprem.Visible = true;
            txtappnorem.Visible = true;
            lblrem.Visible = true;
            txtrem.Visible = true;
            btnfrwd.Visible = true;
            if (e.CommandName == "new")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];
                string requestNo = row.Cells[1].Text;

                txtappnorem.Text = requestNo;
            }
        }

        protected void btnfrwd_Click(object sender, EventArgs e)
        {
            viewcrbo bo = new viewcrbo();
            bo.app_no = txtappnorem.Text;
            bo.Remarks = txtrem.Text;
            viewcrbll bl = new viewcrbll();
            bl.forward(bo);
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Verification message", "alert('Remarks added successfully');", true);
            txtappnorem.Text = string.Empty;
            txtrem.Text = string.Empty;
            //GridView1.DataSource
            //GridView1.DataBind();

        }
       
        protected void btnview_Click(object sender, EventArgs e)
        {
            IVIEWCRBO objbbo = new empbobject.viewcrbo();

            IVIEWCRBLL objapp = new viewcrbll();
            //string check = bo.app_no.ToString();

            if (!String.IsNullOrEmpty(txtappno.Text))
            {
                objbbo.app_no = txtappno.Text;
            }
            else
            {
                objbbo.app_no = null;
            }
            if (!String.IsNullOrEmpty(txtmrgeloc.Text))
            {
                objbbo.mrgeloc = txtmrgeloc.Text;
            }
            else
            {
                objbbo.mrgeloc = null;
            }
            if (!String.IsNullOrEmpty(txthusbandname.Text))
            {
                objbbo.hname = txthusbandname.Text;
            }
            else
            {
                objbbo.hname = null;
            }
            if (!String.IsNullOrEmpty(txtwname.Text))
            {
                objbbo.wname = txtwname.Text;
            }
            else
            {
                objbbo.wname = null;
            }

            DataTable dt = objapp.ViewbyCR(objbbo);
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "No applications  to display";
                }
                else
                {

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Error in dispalying applications ";
            }
            
        }

        protected void txtappnorem_TextChanged(object sender, EventArgs e)
        {
            
                }

        //protected void txtrem_TextChanged(object sender, EventArgs e)
        //{
        //    txtrem.Visible = true;
        //}
        //protected void txtappnorem_TextChanged(object sender, EventArgs e)
        //{
        //    txtrem.Visible = true;
        //}
    }
}