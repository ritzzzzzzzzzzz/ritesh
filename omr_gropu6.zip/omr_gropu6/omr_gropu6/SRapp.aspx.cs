﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empbusiness;
using Types;
using empbobject;
using System.Data;
namespace omr_gropu6
{
    public partial class SRapp : System.Web.UI.Page
    {
        string status;
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Btnall_Click(object sender, EventArgs e)
        {

            bindgrid();
        }
        private void bindgrid()
        {
            try
            { 
            IBuisness objapp = new clsbuisness();
            DataTable dt = objapp.Viewallsr();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    GridView1.Visible = false;
                    lblmsg.Visible = true;
                    lblmsg.Text = "No applications  to display";
                }
                else
                {

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                GridView1.Visible = false;
                lblmsg.Visible = true;
                lblmsg.Text = "Error in dispalying applications ";
            }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            { 
            IBO objbo = new empbobject.SRappbo();
            IBuisness objapp = new clsbuisness();
            if (e.CommandName == "new")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index]; 
                string requestNo = row.Cells[0].Text;
                objbo.idd = requestNo;
                objbo.Status = "Approved";               
            }

            else 
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];
                string requestNo = row.Cells[0].Text;
                objbo.idd = requestNo;
                objbo.Status = "Rejected";
            }
            int result = objapp.srappstatus(objbo);
            if (result > 0)
            {
                Response.Write("<script>alert('application " + objbo.Status + "')</script>");
                bindgrid();
            }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }
        //protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        //{

        //    IBO objbo = new empbobject.clsbo();
        //    IBuisness objapp = new clsbuisness();
        //    objbo.Status = status;
        //    string s = GridView1.SelectedValue.ToString();
        //    for (int i = 0; i < GridView1.Rows.Count; i++)
        //    {
        //        if (GridView1.SelectedIndex == i)
        //        {
        //            if (GridView1.Rows[i].Cells[7].Text != null)
        //            {
        //                int result = objapp.srappstatus(objbo);
        //                if (result > 0)
        //                {
        //                    Response.Write("<script>alert('" + status + "'' application')</script>");
        //                }
        //                else
        //                {
        //                    Response.Write("<script>alert('wrong application')</script>");
        //                }
        //            }
        //            else
        //            {
        //                Response.Write("<script>alert('Sorry no remarks are there')</script>");
        //            }

        //        }

        //    }
        //}



    } }