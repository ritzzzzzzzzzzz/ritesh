﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using iTextSharp;
using empbobject;
using empbusiness;
using Types;
using System.Data;
namespace omr_gropu6
{
    public partial class generatecertificate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
         
            IBO objbo = new empbobject.clsbo();
            IBuisness objapp = new clsbuisness();
            if (e.CommandName == "up")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];
                string app = row.Cells[0].Text;
                Session["id"] = app;
                Response.Redirect("Certificate.aspx");
               

               
            }
        }
        private void bindgrid()
        {
            IBuisness objapp = new clsbuisness();
            DataTable dt = objapp.Viewallstatus();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {

                    Response.Write("<script>alert('No applications  to display')</script>");
                    GridView1.Visible = false;

                }
                else
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = dt;
                    GridView1.DataBind();

                }
            }
            else
            {
                Response.Write("<script>alert('Error in dispalying applications')</script>");


            }

        }

        protected void Btnall_Click(object sender, EventArgs e)
        {


            bindgrid();
        }
    }
}