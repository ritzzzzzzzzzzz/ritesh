﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empbusiness;
using Types;
using empbobject;
namespace omr_gropu6
{
    public partial class View_application : System.Web.UI.Page
    {
        string s;
        string st = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }
        protected void Btnall_Click(object sender, EventArgs e)
        {try
            { 
            txtid.Text = "";
            txthusband.Text = "";
            txtwife.Text = "";
            txtloc.Text = "";
            bindgrid();

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }

        }
        private void bindgrid()
        {
            try { 
            GridView1.Visible = true;
            IBuisness objapp = new clsbuisness();
            DataTable dt = objapp.Viewall();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    Response.Write("<script>alert('No applications  to display')</script>");
                }
                else
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                Response.Write("<script>alert('Error in dispalying applications')</script>");
            }

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }








        public void viewallapplication()
        {
            IBO objbbo = new empbobject.clsbo();

            IBuisness objapp = new clsbuisness();

            if (!String.IsNullOrEmpty(txtid.Text))
            {
                objbbo.idd = txtid.Text;
            }
            else
            {
                objbbo.idd = null;
            }
            if (!String.IsNullOrEmpty(txtloc.Text))
            {
                objbbo.location = txtloc.Text;
            }
            else
            {
                objbbo.location = null;
            }
            if (!String.IsNullOrEmpty(txthusband.Text))
            {
                objbbo.huband = txthusband.Text;
            }
            else
            {
                objbbo.huband = null;
            }
            if (!String.IsNullOrEmpty(txtwife.Text))
            {
                objbbo.wife = txtwife.Text;
            }
            else
            {
                objbbo.wife = null;
            }

            DataTable dt = objapp.Viewfilter(objbbo);
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {

                    Response.Write("<script>alert('No applications  to display')</script>");
                    GridView1.Visible = false;

                }
                else
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = dt;
                    GridView1.DataBind();

                }
            }
            else
            {
                Response.Write("<script>alert('Error in dispalying applications')</script>");


            }

        }

        protected void Txtremark_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Btnsearch_Click1(object sender, EventArgs e)
        {
            try { 
            viewallapplication();
            txtid.Text = "";
            txthusband.Text = "";
            txtwife.Text = "";
            txtloc.Text = "";

        }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
}

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            try
            {
                p1.Visible = false;
                GridView1.Visible = false;
                if (e.CommandName == "new")
                {
                    IBO objbo = new empbobject.clsbo();
                    IBuisness objapp = new clsbuisness();
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = GridView1.Rows[index];
                    string app1 = row.Cells[0].Text;
                    DataTable dt = objapp.all(app1);
                    if (dt != null)
                    {
                        if (dt.Rows.Count == 0)
                        {

                            Response.Write("<script>alert('No applications  to display')</script>");



                        }
                        else
                        {

                            dvdetails.DataSource = dt;
                            dvdetails.DataBind();

                        }
                    }
                    else
                    {
                        Response.Write("<script>alert('Error in dispalying applications')</script>");


                    }

                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        
        }

        protected void dvdetails_ItemCommand(object sender, DetailsViewCommandEventArgs e)
        {try
            { 

            if (e.CommandName == "Up")
            {
                dvdetails.Visible = false;
                p1.Visible = true;
            }

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }
    }
}