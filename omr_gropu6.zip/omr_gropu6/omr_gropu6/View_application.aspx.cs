﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empbusiness;
using Types;
using empbobject;
namespace omr_gropu6
{
    public partial class View_application : System.Web.UI.Page
    {
        string s;
        string st = "";
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Btnall_Click(object sender, EventArgs e)
        {
           
            bindgrid();
        }
        private void bindgrid()
        {
            IBuisness objapp = new clsbuisness();
            DataTable dt = objapp.Viewall();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "No applications  to display";
                }
                else
                {
                   
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Error in dispalying applications ";
            }

        }



        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            IBuisness objapp = new clsbuisness();
            s = GridView1.SelectedValue.ToString();
            DataTable dt = objapp.detailsviewapplication(s);
            if (dt.Rows.Count > 0)
            {
               
                txtwifeage.Text = dt.Rows[0]["age"].ToString();
                txthubage.Text = dt.Rows[1]["age"].ToString();
                 txtwifeagep.Text= dt.Rows[0]["ageproof"].ToString();
                txtwifeaddp.Text= dt.Rows[0]["address"].ToString();
                txtwifeidp.Text= dt.Rows[0]["id"].ToString();
                txthubagep.Text= dt.Rows[1]["ageproof"].ToString();
                txthubaddp.Text= dt.Rows[1]["address"].ToString();
                txthubidp.Text= dt.Rows[1]["id"].ToString();
                this.mpe.Show();
            }

           
       // mpe.Show();

        }
     
       
        protected void Btnsearch_Click(object sender, EventArgs e)
        {
            viewallapplication();
        }

        protected void btnverify_Click(object sender, EventArgs e)
        {
            IBO objboo = new empbobject.clsbo();
          IBuisness objapp = new clsbuisness();
            
            if (Convert.ToInt32(txthubage.Text) >= 21 && Convert.ToInt32(txtwifeage.Text) >= 18 && txtwifeagep.Text != null && txtwifeidp.Text != null &&
                txtwifeaddp.Text != null && txthubagep.Text != null && txthubaddp.Text != null && txthubidp.Text != null)
            {
                objboo.remark = Txtremark.Text;
            }
            else
            {
                objboo.remark = Txtremark.Text;
            }

            objboo.idd = GridView1.SelectedValue.ToString();
            int intresult = objapp.verifyapplication(objboo);

            if (intresult == 1)
            {
                Response.Write("<script>alert('Details verified successfully')</script>");
                //lblmsg.Text = "Details verified successfully";

            }
            else if (intresult == -1)
            {
                Response.Write("<script>alert('same id already')</script>");
            }
        }

        protected void Btnviewdetails_Click(object sender, EventArgs e)
        {
           
        }

        protected void Btnwifeagep_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename="+s+"ageproofp.pdf");
            Response.TransmitFile(Server.MapPath(txtwifeagep.Text));
            Response.End();
        }

        protected void Btnwifeaddp_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + s + "wifeaddp.pdf");
            Response.TransmitFile(Server.MapPath(txtwifeaddp.Text));
            Response.End();
        }

        protected void Btnwifeidp_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + s + "wifeidp.pdf");
            Response.TransmitFile(Server.MapPath(txtwifeidp.Text));
            Response.End();
        }

        protected void Btnhubage_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + s + "husageproofp.pdf");
            Response.TransmitFile(Server.MapPath(txtwifeidp.Text));
            Response.End();
        }

        protected void Btnhubaddp_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + s + "husaddp.pdf");
            Response.TransmitFile(Server.MapPath(txthubaddp.Text));
            Response.End();
        }

        protected void Btnhubidp_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + s + "husidp.pdf");
            Response.TransmitFile(Server.MapPath(txthubidp.Text));
            Response.End();
        }

        public void viewallapplication()
        {
            IBO objbbo = new empbobject.clsbo();

            IBuisness objapp = new clsbuisness();
            
            if (!String.IsNullOrEmpty(txtid.Text))
            {
                objbbo.idd =txtid.Text;
            }
            else
            {
                objbbo.idd = null;
            }
            if (!String.IsNullOrEmpty(txtloc.Text))
            {
                objbbo.location = txtloc.Text;
            }
            else
            {
                objbbo.location = null;
            }
            if (!String.IsNullOrEmpty(txthusband.Text))
            {
                objbbo.huband = txthusband.Text;
            }
            else
            {
                objbbo.huband = null;
            }
            if (!String.IsNullOrEmpty(txtwife.Text))
            {
                objbbo.wife = txtwife.Text;
            }
            else
            {
                objbbo.wife = null;
            }
           
            DataTable dt = objapp.Viewfilter(objbbo);
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "No applications  to display";
                }
                else
                {
                    
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Error in dispalying applications ";
            }

        }


        //protected void btnforward_Click(object sender, EventArgs e)
        //{
        //    clsbuisness objapp = new clsbuisness();
        //    int intresult = objapp.verifyapplication(st, GridView1.SelectedValue.ToString());

        //    if (intresult == 1)
        //    {
        //        Response.Write("<script>alert('Details verified successfully')</script>");
        //        //lblmsg.Text = "Details verified successfully";

        //    }
        //    else if (intresult == -1)
        //    {
        //        Response.Write("<script>alert('same id already')</script>");
        //    }
        //}
    }
}