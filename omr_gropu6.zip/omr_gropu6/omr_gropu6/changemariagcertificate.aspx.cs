﻿using empbusiness;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Types;

namespace omr_gropu6
{
    public partial class changemariagcertificate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            bindgrid();
        }
        private void bindgrid()
        {
            IBuisness objapp = new clsbuisness();
            DataTable dt = objapp.viewchangereq();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    Label1.Visible = true;
                    Label1.Text = "No Change requests  to display";
                }
                else
                {

                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                Label1.Visible = true;
                Label1.Text = "Error in dispalying chnge requests ";
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            GridView1.Visible = false;
            IBO objbo = new empbobject.clsbo();
            IBuisness objapp = new clsbuisness();
            if (e.CommandName == "up")
            {
                int index = Convert.ToInt32(e.CommandArgument);
                GridViewRow row = GridView1.Rows[index];
                string app = row.Cells[1].Text;
                objbo.idd = app;
            
                DataTable dt = objapp.viewchangevalue(objbo);
              
                dvchangevalue.DataSource = dt;
                dvchangevalue.DataBind();
                dvchangevalue.Visible = true;
            }
        }

        protected void dvchangevalue_ItemCommand(object sender, DetailsViewCommandEventArgs e)
        {
            dvchangevalue.Visible = false;
            IBO objbo =new empbobject.clsupdatecertificate();
            IBuisness objapp = new clsbuisness();
           
            if (e.CommandName == "Up")
            {

                DetailsViewRow row = dvchangevalue.Rows[0];
                objbo.idd = row.Cells[1].Text;
                objbo.col_name =dvchangevalue.Rows[1].Cells[1].Text;
                objbo.old_val = dvchangevalue.Rows[2].Cells[1].Text;
                objbo.new_val = dvchangevalue.Rows[3].Cells[1].Text;
                objbo.statuss = dvchangevalue.Rows[4].Cells[1].Text;
                objbo.remarkss = dvchangevalue.Rows[5].Cells[1].Text;
                int a = objapp.changecertificate(objbo);
                if (a > 0)
                {
                    Response.Write("<script>alert('updated succesfully')</script>");
                }

            }
            if (e.CommandName == "Can")
            {
                dvchangevalue.Visible = false;
                
            }
            GridView1.Visible = true;
        }
    }
}