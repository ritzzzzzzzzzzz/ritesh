﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using Types;
using empbusiness;
namespace WebApplication9
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string name = "";
                DataTable dt = new DataTable();
                IBuisness obpp = new clsbuisness();
                if (Session["id"] != null)
                {
                    name = Session["id"].ToString();
                }
                else if (Session["idd"] != null)
                {
                    name = Session["idd"].ToString();
                }
                dt = obpp.viewcertificate(name);
                if (dt != null)
                {
                    TextBox3.Text = dt.Rows[0]["application_no"].ToString();
                    txthname.Text = dt.Rows[0]["Husbandname"].ToString();


                    TextBox4.Text = dt.Rows[0]["wifename"].ToString();
                    TextBox5.Text = dt.Rows[0]["marraigedate"].ToString();
                    TextBox6.Text = dt.Rows[0]["mgrlocation"].ToString();

                    TextBox10.Text = dt.Rows[0]["district"].ToString();
                    TextBox11.Text = dt.Rows[0]["address"].ToString();

                    TextBox13.Text = dt.Rows[0]["state"].ToString();
                    TextBox14.Text = dt.Rows[0]["nationality"].ToString();

                }

                else
                {
                    lblmsg.Visible = true;
                    lblmsg.Text = "Error in dispalying applications ";
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try { 
            if (Session["id"] != null)
            {
                Session.Abandon();
                Response.Redirect("generatecertificate.aspx");
            }
            else
            {
                Session.Abandon();
                Response.Redirect("changemariagcertificate.aspx");
            }
        }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
}
    }
}