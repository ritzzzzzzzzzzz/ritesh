﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empbusiness;
using Types;
using empbobject;
using System.Data;

namespace omr_gropu6
{
    public partial class viewforsrass : System.Web.UI.Page
    {
        string s;
        string st = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
        }
        protected void Btnall_Click(object sender, EventArgs e)
        {
            try { 
            bindgrid();
            txtid.Text = "";
            txthusband.Text = "";
            txtwife.Text = "";
            txtloc.Text = "";

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }
        private void bindgrid()
        {
            try { 
            IBuisness objapp = new clsbuisness();
            DataTable dt = objapp.Viewall();
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                    Response.Write("<script>alert('No applications  to display')</script>");
                }
                else
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                }
            }
            else
            {
                Response.Write("<script>alert('Error in dispalying applications')</script>");
            }

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }



        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try { 
            IBuisness objapp = new clsbuisness();
            s = GridView1.SelectedValue.ToString();
            DataTable dt = objapp.detailsviewapplication(s);
            if (dt.Rows.Count > 0)
            {

                txtwifeage.Text = dt.Rows[0]["age"].ToString();
                txthubage.Text = dt.Rows[1]["age"].ToString();
                txtwifeagep.Text = dt.Rows[0]["ageproof"].ToString();
                txtwifeaddp.Text = dt.Rows[0]["address"].ToString();
                txtwifeidp.Text = dt.Rows[0]["id"].ToString();
                txthubagep.Text = dt.Rows[1]["ageproof"].ToString();
                txthubaddp.Text = dt.Rows[1]["address"].ToString();
                txthubidp.Text = dt.Rows[1]["id"].ToString();
                this.mpe.Show();
            }
            else

            {
                Response.Write("<script>alert('no records to display')</script>");
            }


            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
            // mpe.Show();

        }




        protected void btnverify_Click(object sender, EventArgs e)
        {
            try
            { 
            if (!string.IsNullOrEmpty(Txtremark.Text))
            {
                IBO objboo = new empbobject.clsbo();
                IBuisness objapp = new clsbuisness();
                if (!string.IsNullOrEmpty(Txtremark.Text))
                {
                    if (Convert.ToInt32(txthubage.Text) >= 21 && Convert.ToInt32(txtwifeage.Text) >= 18 && txtwifeagep.Text != null && txtwifeidp.Text != null &&
                        txtwifeaddp.Text != null && txthubagep.Text != null && txthubaddp.Text != null && txthubidp.Text != null)
                    {
                        objboo.remark = Txtremark.Text;
                    }
                    else
                    {
                        objboo.remark = Txtremark.Text;
                    }

                    objboo.idd = GridView1.SelectedValue.ToString();
                    int intresult = objapp.verifyapplication(objboo);

                    if (intresult == 1)
                    {
                        Response.Write("<script>alert('Details verified successfully')</script>");

                        //lblmsg.Text = "Details verified successfully";

                    }
                    else if (intresult == -1)
                    {
                        Response.Write("<script>alert('same id already')</script>");
                    }

                }
            }
            else
            {
                Response.Write("<script>alert('give remark')</script>");
            }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }


        }

        protected void Btnviewdetails_Click(object sender, EventArgs e)
        {

        }

        protected void Btnwifeagep_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + GridView1.SelectedValue.ToString() + "ageproofp.pdf");
            Response.TransmitFile(Server.MapPath(txtwifeagep.Text));
            Response.End();
        }

        protected void Btnwifeaddp_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + GridView1.SelectedValue.ToString() + "wifeaddp.pdf");
            Response.TransmitFile(Server.MapPath(txtwifeaddp.Text));
            Response.End();
        }

        protected void Btnwifeidp_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + GridView1.SelectedValue.ToString() + "wifeidp.pdf");
            Response.TransmitFile(Server.MapPath(txtwifeidp.Text));
            Response.End();
        }

        protected void Btnhubage_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + GridView1.SelectedValue.ToString() + "husageproofp.pdf");
            Response.TransmitFile(Server.MapPath(txtwifeidp.Text));
            Response.End();
        }

        protected void Btnhubaddp_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + GridView1.SelectedValue.ToString() + "husaddp.pdf");
            Response.TransmitFile(Server.MapPath(txthubaddp.Text));
            Response.End();
        }

        protected void Btnhubidp_Click(object sender, EventArgs e)
        {
            Response.ContentType = "pdf";
            Response.AppendHeader("Content-Disposition", "attachment;filename=" + GridView1.SelectedValue.ToString() + "husidp.pdf");
            Response.TransmitFile(Server.MapPath(txthubidp.Text));
            Response.End();
        }

        public void viewallapplication()
        {
            IBO objbbo = new empbobject.clsbo();

            IBuisness objapp = new clsbuisness();

            if (!String.IsNullOrEmpty(txtid.Text))
            {
                objbbo.idd = txtid.Text;
            }
            else
            {
                objbbo.idd = null;
            }
            if (!String.IsNullOrEmpty(txtloc.Text))
            {
                objbbo.location = txtloc.Text;
            }
            else
            {
                objbbo.location = null;
            }
            if (!String.IsNullOrEmpty(txthusband.Text))
            {
                objbbo.huband = txthusband.Text;
            }
            else
            {
                objbbo.huband = null;
            }
            if (!String.IsNullOrEmpty(txtwife.Text))
            {
                objbbo.wife = txtwife.Text;
            }
            else
            {
                objbbo.wife = null;
            }

            DataTable dt = objapp.Viewfilter(objbbo);
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {

                    Response.Write("<script>alert('No applications  to display')</script>");
                    GridView1.Visible = false;

                }
                else
                {
                    GridView1.Visible = true;
                    GridView1.DataSource = dt;
                    GridView1.DataBind();

                }
            }
            else
            {
                Response.Write("<script>alert('Error in dispalying applications')</script>");


            }

        }

        protected void Txtremark_TextChanged(object sender, EventArgs e)
        {

        }

    

        protected void Btnsearch_Click(object sender, EventArgs e)
        {
            try { 
            viewallapplication();
            txtid.Text = "";
            txthusband.Text = "";
            txtwife.Text = "";
            txtloc.Text = "";
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }



        //protected void btnforward_Click(object sender, EventArgs e)
        //{
        //    clsbuisness objapp = new clsbuisness();
        //    int intresult = objapp.verifyapplication(st, GridView1.SelectedValue.ToString());

        //    if (intresult == 1)
        //    {
        //        Response.Write("<script>alert('Details verified successfully')</script>");
        //        //lblmsg.Text = "Details verified successfully";

        //    }
        //    else if (intresult == -1)
        //    {
        //        Response.Write("<script>alert('same id already')</script>");
        //    }
        //}
    }
}