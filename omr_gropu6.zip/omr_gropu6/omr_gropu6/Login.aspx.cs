﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using empbusiness;
using Types;
using empbobject;
namespace omr_gropu6
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!String.IsNullOrWhiteSpace(Request.Params["logout"]))
            {
                FormsAuthentication.SignOut();
                Response.Redirect("./");
            }
        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            ILOGINbo objloginbo = new empbobject.clslogin();
            IBuisness objbuis = new clsbuisness();
            if (RadioButtonList1.SelectedItem.Value == "Employee")
            {
              
                    objloginbo.Username = Convert.ToInt32(txtUserName.Text);
                objloginbo.txtpwd = txtPwd.Text;
                 clsbuisness objb1 = new clsbuisness();
                FormsAuthentication.SetAuthCookie(
                this.txtUserName.Text.Trim(), false);
                string emp = objbuis.emplogin(objloginbo);

                Session["emp"] = txtUserName.Text;
                String ReturnUrl;
                if (emp == string.Empty)
                {
                    Response.Write("<script>alert('Invalid Login credentails')</script>");
                    popUpPanel.Visible = true;
                }
                else if (emp == "SR")
                {
                    FormsAuthenticationTicket ticket1 =
              new FormsAuthenticationTicket(
                   1,                                  
                   this.txtUserName.Text.Trim(),  
                   DateTime.Now,                     
                   DateTime.Now.AddMinutes(10),         
                   false,      
                   "SR"                              
                   );
                    HttpCookie cookie1 = new HttpCookie(
           FormsAuthentication.FormsCookieName,
           FormsAuthentication.Encrypt(ticket1));
                    Response.Cookies.Add(cookie1);

                    // 4. Do the redirect. 
                    
                    // the login is successful
                    if (Request.QueryString["ReturnUrl"] == null)
                    {
                        ReturnUrl = "View_application.aspx";
                    }
                    else
                    {
                        ReturnUrl = Request.QueryString["SRapp"];
                    }
                    Response.Redirect(ReturnUrl);

                }
                else
                {
                    FormsAuthenticationTicket ticket1 =
             new FormsAuthenticationTicket(
                  1,                                 
                  this.txtUserName.Text.Trim(),  
                  DateTime.Now,                      
                  DateTime.Now.AddMinutes(10),        
                  false,     
                  "SRAssistant"                             
                                                
                  );
                    HttpCookie cookie1 = new HttpCookie(
           FormsAuthentication.FormsCookieName,
           FormsAuthentication.Encrypt(ticket1));
                    Response.Cookies.Add(cookie1);

                    if (Request.QueryString["ReturnUrl"] == null)
                    {
                        ReturnUrl = "WebForm2.aspx";
                    }
                    else
                    {
                        ReturnUrl = Request.QueryString["ReturnUrl"];
                    }
                    Response.Redirect(ReturnUrl);
                   
                }
            }
            else
            {
                Response.Write("<script>alert('choose right option')</script>");
            }
        }
    }
}