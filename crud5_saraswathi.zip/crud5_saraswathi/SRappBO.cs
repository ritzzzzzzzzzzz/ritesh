﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empbobject
{
    class SRappBO
    {
        int ApplicationNo;
        string statuss;
        public string Status
        {
            get { return statuss; }
            set { statuss = value; }
        }
        string remarkk;
        public string remark
        {
            get { return remarkk; }
            set { remarkk = value; }

        }

        public int ApplicationNo1
        {
            get
            {
                return ApplicationNo;
            }

            set
            {
                ApplicationNo = value;
            }
        }
    }
}
