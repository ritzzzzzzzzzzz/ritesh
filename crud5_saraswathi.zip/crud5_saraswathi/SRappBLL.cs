﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using empdal;
using System.Data;
using Types;

namespace empbusiness
{
    public class SRappBLL:IBuisness
    {
        public int srappstatus(IBO objbo)
        {
            IDAL objdatalayer = new clsdal();
            return objdatalayer.srappstatus(objbo);
        }
        public DataTable Viewallsr()
        {
            DataTable dt;
            IDAL datalayer = new clsdal();
            dt = datalayer.Viewallsr();

            return dt;
        }
    }
}
