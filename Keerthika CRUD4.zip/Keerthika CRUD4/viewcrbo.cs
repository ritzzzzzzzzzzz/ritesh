﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace empbobject
{
    public class viewcrbo
    {

        int cr_id;
            int Application_no;
            DateTime MarraigeDate;
            string MgrLocation;
            string Firstname;
            string remarks;
        public int CR_ID
        {
            get { return cr_id; }
            set { cr_id = value; }
        }
            public int app_no
            {
                get { return Application_no; }
                set { Application_no = value; }
            }
            public DateTime mrgedate
            {
                get { return MarraigeDate; }
                set { MarraigeDate = value; }
            }
            public string mrgeloc
            {
                get { return MgrLocation; }
                set { MgrLocation = value; }
            }
            public string fname
            {
                get { return Firstname; }
                set { Firstname = value; }
            }

            public string Remarks
            {
                get
                {
                    return remarks;
                }

                set
                {
                    remarks = value;
                }
            }
        public viewcrbo()
        {

        }
        public viewcrbo(int cr_id,string remarks)
        {
            this.cr_id = cr_id;
            this.remarks = remarks;
        }
        }
}
