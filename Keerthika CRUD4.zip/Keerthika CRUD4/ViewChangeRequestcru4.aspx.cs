﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empbusiness;
using empbobject;

namespace omr_gropu6
{
    public partial class ViewChangeRequestcru4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void btnviewall_Click(object sender, EventArgs e)
        {
            viewcrbll bll = new viewcrbll();
            GridView1.DataSource = bll.viewall();
            GridView1.DataBind();
        }
        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClientScript.RegisterClientScriptBlock(this.GetType(), "Verification message", "alert('Verified');", true);
            lblcrid.Visible = true;
            txtcrid.Visible = true;
            lblrem.Visible = true;
            txtremarks.Visible = true;
            btnfrwd.Visible= true;

        }
        protected void btnfrwd_Click(object sender, EventArgs e)
        {
            viewcrbo bo = new viewcrbo();
            bo.CR_ID=int.Parse(txtcrid.Text);
            bo.Remarks = txtremarks.Text;
            viewbll bl = new viewbll();
            bl.forward();

        }
    }
}