﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TraINReservationSystem
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (DropDownList1.SelectedValue.ToString())
            {
                case "reserve train":
                    Response.Redirect("ReserveTrain.aspx");
                    break;
                case "view reservation":
                    Response.Redirect("view.aspx");
                    break;


            }
        }
    }
}
