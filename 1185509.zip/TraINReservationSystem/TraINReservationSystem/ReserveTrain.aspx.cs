﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TraINReservationSystem
{
    public partial class ReserveTrain : System.Web.UI.Page
    {
        string constr;
        SqlConnection connection;
        SqlCommand command;
        SqlDataAdapter da;
        DataSet ds;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            

        }
        public void filldataset()
        {
            string constr = ConfigurationManager.ConnectionStrings["myconn"].ConnectionString;
            connection = new SqlConnection(constr);
            command = new SqlCommand("select * from tbl_TrainReservation1185509", connection);

            command.CommandType = CommandType.Text;
            da = new SqlDataAdapter();
            da.SelectCommand = command;
            ds = new DataSet();
            da.Fill(ds);
            DataTable dt = ds.Tables[0];
            DataColumn[] keys = new DataColumn[1];
            keys[0] = dt.Columns["ReserationID"];
            dt.PrimaryKey = keys;
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            
            Response.Write("successfull");
            Response.Redirect("view.aspx");

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if(DropDownList3.SelectedValue==Items[0].ToString())
            {

                TextBox1.Text = "600";
            }
            else if(DropDownList3.SelectedValue == Items[1].ToString())
            {
                TextBox1.Text = "900";
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            int result = Convert.ToInt32(TextBox3.Text);
            result = (Convert.ToInt32(TextBox1.Text)) * (Convert.ToInt32(TextBox2.Text));

        }
    }
}