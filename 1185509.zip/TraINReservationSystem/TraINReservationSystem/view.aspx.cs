﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace TraINReservationSystem
{
    public partial class view : System.Web.UI.Page
    {
        string constr;
        SqlConnection conn;
        SqlCommand com;
        SqlDataAdapter da;
        DataSet ds;
        SqlCommandBuilder cb;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
           
            
        }
    }
}