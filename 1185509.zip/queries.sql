create table tbl_TrainReservation1185509
(
reservationID int primary key identity(1,1000),
fromlocation varchar(20),
tolocation varchar(20),
Noofpassengers int,
totalamount int
)
