﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
namespace WebApplication9
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string constr = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_certificate", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Application_no", int.Parse(TextBox3.Text));
            SqlDataReader sdr = cmd.ExecuteReader();

            if (sdr.Read())
            {
                txthname.Text = sdr["husbandname"].ToString();

                TextBox4.Text = sdr["wifename"].ToString();
                TextBox5.Text = sdr["MarraigeDate"].ToString();
                TextBox6.Text  = sdr["MgrLocation"].ToString();
                TextBox9.Text = sdr["Contact_no"].ToString();
                TextBox10.Text = sdr["District"].ToString();
                TextBox11.Text = sdr["State"].ToString();
                TextBox12.Text = sdr["Email"].ToString();
                TextBox13.Text = sdr["Nationality"].ToString();
                TextBox14.Text = sdr["Address"].ToString();

                sdr.Close();
            }
            cmd.Dispose();
            con.Close();
        }
    }
}