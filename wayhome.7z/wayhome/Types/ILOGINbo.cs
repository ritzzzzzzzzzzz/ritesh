﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    public interface ILOGINbo
    {
        int Username { get; set; }
        string txtpwd { get; set; }
    }
}
