﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
namespace empbobject
{
   public class clsupdatecertificate:IBO
    {
   
        string iid, col_Name, Old_val, New_val, status, remarks;

        public string Iid
        {
            get
            {
                return iid;
            }

            set
            {
                iid = value;
            }
        }

        public string Col_Name
        {
            get
            {
                return col_Name;
            }

            set
            {
                col_Name = value;
            }
        }

        public string Old_val1
        {
            get
            {
                return Old_val;
            }

            set
            {
                Old_val = value;
            }
        }

        public string New_val1
        {
            get
            {
                return New_val;
            }

            set
            {
                New_val = value;
            }
        }

        public string Status2
        {
            get
            {
                return status;
            }

            set
            {
                status = value;
            }
        }

        public string Remarks
        {
            get
            {
                return remarks;
            }

            set
            {
                remarks = value;
            }
        }
    }
}
