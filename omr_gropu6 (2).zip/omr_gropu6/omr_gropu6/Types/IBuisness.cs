﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
namespace Types
{
   public interface IBuisness
    {
        string emplogin(ILOGINbo obj);
        DataTable Viewallstatus();
        DataTable Viewall();
        DataTable Viewallsr();
        DataTable Viewfilter(IBO objbo);
        DataTable detailsviewapplication(string s);
        int verifyapplication(IBO objvp);
        int srappstatus(IBO objsr);
        DataTable Viewallcr();
        int CRstatus(IBO objcr);
        DataTable viewchangereq();
        DataTable viewchangevalue(IBO objcv);
        int changecertificate(IBO objcr);
    }
}
